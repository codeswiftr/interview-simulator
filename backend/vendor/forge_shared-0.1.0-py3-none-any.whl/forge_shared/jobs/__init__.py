"""forge-shared jobs: DB-backed async job queue.

Lightweight replacement for Celery Beat for simple periodic/scheduled jobs.
Supports PostgreSQL (FOR UPDATE SKIP LOCKED) and SQLite (BEGIN IMMEDIATE).

Usage:
    from forge_shared.jobs import JobQueue

    queue = JobQueue(db_url=settings.database_url)
    await queue.init()
    await queue.enqueue("weekly_email", payload={}, run_at=next_monday_9am_utc())
    await queue.run_worker({"weekly_email": my_handler}, poll_interval=60)
"""

from forge_shared.jobs.queue import JobQueue, JobHandler

__all__ = ["JobQueue", "JobHandler"]
