"""DB-backed async job queue for scheduled and background tasks.

Supports PostgreSQL (FOR UPDATE SKIP LOCKED) and SQLite (BEGIN IMMEDIATE).
Designed as a lightweight replacement for Celery Beat for simple periodic jobs.

Usage:
    from forge_shared.jobs import JobQueue

    queue = JobQueue(db_url="postgresql+asyncpg://...")
    await queue.init()

    # Enqueue a job
    await queue.enqueue("weekly_email", payload={}, run_at=next_monday_9am_utc())

    # Run the worker loop
    handlers = {"weekly_email": my_handler}
    await queue.run_worker(handlers, poll_interval=60, job_types=["weekly_email"])
"""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from collections.abc import Callable, Coroutine
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)

# Handler type: async callable that receives a payload dict
JobHandler = Callable[[dict[str, Any]], Coroutine[Any, Any, None]]


class JobQueue:
    """Async DB-backed job queue.

    Supports PostgreSQL and SQLite via raw asyncpg / aiosqlite connections.
    Uses row-level locking to allow multiple workers without double-processing.

    Args:
        db_url: Database URL. Supports:
            - ``postgresql+asyncpg://...`` — uses asyncpg + FOR UPDATE SKIP LOCKED
            - ``sqlite+aiosqlite:///...`` — uses aiosqlite + BEGIN IMMEDIATE
    """

    def __init__(self, db_url: str) -> None:
        self._db_url = db_url
        self._is_postgres = "postgresql" in db_url or "postgres" in db_url
        self._conn: Any = None  # asyncpg.Connection or aiosqlite.Connection
        self._initialized = False

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def init(self) -> None:
        """Initialize DB connection and create the jobs table if needed."""
        if self._initialized:
            return

        if self._is_postgres:
            await self._init_postgres()
        else:
            await self._init_sqlite()

        self._initialized = True
        logger.info("JobQueue initialized (backend=%s)", "postgres" if self._is_postgres else "sqlite")

    async def _init_postgres(self) -> None:
        """Initialize PostgreSQL connection via asyncpg."""
        try:
            import asyncpg  # type: ignore[import-untyped]
        except ImportError as exc:  # pragma: no cover
            raise ImportError(
                "asyncpg is required for PostgreSQL support. "
                "Install it with: pip install asyncpg"
            ) from exc

        # Strip SQLAlchemy dialect prefix — asyncpg uses raw DSN
        dsn = self._db_url.replace("postgresql+asyncpg://", "postgresql://")
        self._conn = await asyncpg.connect(dsn)
        await self._conn.execute(_CREATE_TABLE_POSTGRES)

    async def _init_sqlite(self) -> None:
        """Initialize SQLite connection via aiosqlite."""
        try:
            import aiosqlite  # type: ignore[import-untyped]
        except ImportError as exc:  # pragma: no cover
            raise ImportError(
                "aiosqlite is required for SQLite support. "
                "Install it with: pip install aiosqlite"
            ) from exc

        # Strip SQLAlchemy dialect prefix
        path = self._db_url.replace("sqlite+aiosqlite:///", "").replace("sqlite:///", "")
        self._conn = await aiosqlite.connect(path)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.execute(_CREATE_TABLE_SQLITE)
        await self._conn.commit()

    async def close(self) -> None:
        """Close the database connection."""
        if self._conn is not None:
            await self._conn.close()
            self._conn = None
            self._initialized = False

    # ------------------------------------------------------------------
    # Enqueue
    # ------------------------------------------------------------------

    async def enqueue(
        self,
        job_type: str,
        payload: dict[str, Any] | None = None,
        run_at: datetime | None = None,
        max_retries: int = 3,
    ) -> str:
        """Add a job to the queue.

        Idempotency note: duplicate ``(job_type, run_at)`` pairs within a
        1-second window are NOT deduplicated automatically. Callers should
        check for pending jobs before enqueuing (see ``has_pending``).

        Args:
            job_type: Logical job name, e.g. ``"weekly_email"``.
            payload: JSON-serialisable dict passed to the handler.
            run_at: When to run the job. Defaults to now (UTC).
            max_retries: Maximum delivery attempts before marking as failed.

        Returns:
            Job ID (UUID string).
        """
        if not self._initialized:
            await self.init()

        job_id = str(uuid.uuid4())
        now_utc = datetime.now(timezone.utc)
        scheduled_at = run_at or now_utc
        payload_json = json.dumps(payload or {})

        if self._is_postgres:
            await self._conn.execute(
                _INSERT_JOB_POSTGRES,
                job_id,
                job_type,
                payload_json,
                scheduled_at,
                max_retries,
                now_utc,
            )
        else:
            await self._conn.execute(
                _INSERT_JOB_SQLITE,
                (
                    job_id,
                    job_type,
                    payload_json,
                    scheduled_at.isoformat(),
                    max_retries,
                    now_utc.isoformat(),
                ),
            )
            await self._conn.commit()

        logger.info(
            "Enqueued job type=%s id=%s run_at=%s",
            job_type,
            job_id,
            scheduled_at.isoformat(),
        )
        return job_id

    # ------------------------------------------------------------------
    # Pending check (idempotency helper)
    # ------------------------------------------------------------------

    async def has_pending(self, job_type: str) -> bool:
        """Return True if there is already a pending/running job of this type.

        Used by callers to implement idempotent scheduling (e.g. check before
        enqueuing the next weekly email so duplicate jobs are not created on
        repeated app restarts).

        Args:
            job_type: The job type to check.

        Returns:
            True if at least one pending or running job of this type exists.
        """
        if not self._initialized:
            await self.init()

        if self._is_postgres:
            row = await self._conn.fetchrow(_HAS_PENDING_POSTGRES, job_type)
            return bool(row and row["count"] > 0)
        else:
            async with self._conn.execute(_HAS_PENDING_SQLITE, (job_type,)) as cursor:
                row = await cursor.fetchone()
                return bool(row and row[0] > 0)

    # ------------------------------------------------------------------
    # Worker
    # ------------------------------------------------------------------

    async def run_worker(
        self,
        handlers: dict[str, JobHandler],
        poll_interval: float = 30.0,
        job_types: list[str] | None = None,
    ) -> None:
        """Run the async worker loop until cancelled.

        Polls the DB for due jobs, claims them with row-level locking, calls
        the appropriate handler, and marks them as completed or failed.

        Args:
            handlers: Mapping from job_type to async handler function.
            poll_interval: Seconds between polling cycles.
            job_types: If provided, only poll for these job types.
                       Defaults to all types in ``handlers``.
        """
        if not self._initialized:
            await self.init()

        types_to_poll = job_types or list(handlers.keys())
        logger.info(
            "JobQueue worker started (poll_interval=%.0fs, job_types=%s)",
            poll_interval,
            types_to_poll,
        )

        while True:
            try:
                await self._poll_and_process(handlers, types_to_poll)
            except asyncio.CancelledError:
                logger.info("JobQueue worker cancelled — shutting down")
                raise
            except Exception:
                logger.exception("Unexpected error in JobQueue worker poll cycle")

            await asyncio.sleep(poll_interval)

    async def _poll_and_process(
        self,
        handlers: dict[str, JobHandler],
        job_types: list[str],
    ) -> None:
        """Claim and process one due job per poll cycle."""
        now_utc = datetime.now(timezone.utc)
        job = await self._claim_next_job(job_types, now_utc)
        if job is None:
            return

        job_id: str = job["id"]
        job_type: str = job["job_type"]
        payload: dict[str, Any] = json.loads(job["payload"])

        handler = handlers.get(job_type)
        if handler is None:
            logger.warning("No handler registered for job_type=%s (id=%s)", job_type, job_id)
            await self._mark_failed(job_id, "No handler registered")
            return

        logger.info("Processing job type=%s id=%s", job_type, job_id)
        try:
            await handler(payload)
            await self._mark_completed(job_id)
            logger.info("Completed job type=%s id=%s", job_type, job_id)
        except Exception as exc:
            retry_count: int = job["retry_count"]
            max_retries: int = job["max_retries"]
            logger.exception("Failed job type=%s id=%s (attempt %d/%d)", job_type, job_id, retry_count + 1, max_retries)
            if retry_count + 1 >= max_retries:
                await self._mark_failed(job_id, str(exc))
            else:
                await self._mark_pending(job_id, retry_count + 1)

    async def _claim_next_job(
        self, job_types: list[str], now_utc: datetime
    ) -> dict[str, Any] | None:
        """Claim the next due job using locking to prevent double-processing."""
        if self._is_postgres:
            return await self._claim_next_postgres(job_types, now_utc)
        else:
            return await self._claim_next_sqlite(job_types, now_utc)

    async def _claim_next_postgres(
        self, job_types: list[str], now_utc: datetime
    ) -> dict[str, Any] | None:
        async with self._conn.transaction():
            row = await self._conn.fetchrow(
                _CLAIM_NEXT_POSTGRES,
                job_types,
                now_utc,
            )
            if row is None:
                return None
            # Mark as running within the same transaction
            await self._conn.execute(_MARK_RUNNING_POSTGRES, now_utc, row["id"])
            return dict(row)

    async def _claim_next_sqlite(
        self, job_types: list[str], now_utc: datetime
    ) -> dict[str, Any] | None:
        # SQLite: BEGIN IMMEDIATE for exclusive write lock
        await self._conn.execute("BEGIN IMMEDIATE")
        try:
            placeholders = ",".join("?" * len(job_types))
            async with self._conn.execute(
                _CLAIM_NEXT_SQLITE.format(placeholders=placeholders),
                (*job_types, now_utc.isoformat()),
            ) as cursor:
                row = await cursor.fetchone()

            if row is None:
                await self._conn.execute("ROLLBACK")
                return None

            row_dict = dict(row)
            await self._conn.execute(
                _MARK_RUNNING_SQLITE,
                (now_utc.isoformat(), row_dict["id"]),
            )
            await self._conn.execute("COMMIT")
            return row_dict
        except Exception:
            await self._conn.execute("ROLLBACK")
            raise

    # ------------------------------------------------------------------
    # Status updates
    # ------------------------------------------------------------------

    async def _mark_completed(self, job_id: str) -> None:
        now_utc = datetime.now(timezone.utc)
        if self._is_postgres:
            await self._conn.execute(_MARK_COMPLETED_POSTGRES, now_utc, job_id)
        else:
            await self._conn.execute(_MARK_COMPLETED_SQLITE, (now_utc.isoformat(), job_id))
            await self._conn.commit()

    async def _mark_failed(self, job_id: str, error: str) -> None:
        now_utc = datetime.now(timezone.utc)
        if self._is_postgres:
            await self._conn.execute(_MARK_FAILED_POSTGRES, error, now_utc, job_id)
        else:
            await self._conn.execute(_MARK_FAILED_SQLITE, (error, now_utc.isoformat(), job_id))
            await self._conn.commit()

    async def _mark_pending(self, job_id: str, retry_count: int) -> None:
        if self._is_postgres:
            await self._conn.execute(_MARK_PENDING_POSTGRES, retry_count, job_id)
        else:
            await self._conn.execute(_MARK_PENDING_SQLITE, (retry_count, job_id))
            await self._conn.commit()


# ---------------------------------------------------------------------------
# DDL
# ---------------------------------------------------------------------------

_CREATE_TABLE_POSTGRES = """
CREATE TABLE IF NOT EXISTS forge_jobs (
    id          TEXT        PRIMARY KEY,
    job_type    TEXT        NOT NULL,
    payload     TEXT        NOT NULL DEFAULT '{}',
    status      TEXT        NOT NULL DEFAULT 'pending',
    run_at      TIMESTAMPTZ NOT NULL,
    retry_count INTEGER     NOT NULL DEFAULT 0,
    max_retries INTEGER     NOT NULL DEFAULT 3,
    error       TEXT,
    started_at  TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_forge_jobs_pending
    ON forge_jobs (job_type, run_at)
    WHERE status = 'pending';
"""

_CREATE_TABLE_SQLITE = """
CREATE TABLE IF NOT EXISTS forge_jobs (
    id           TEXT PRIMARY KEY,
    job_type     TEXT NOT NULL,
    payload      TEXT NOT NULL DEFAULT '{}',
    status       TEXT NOT NULL DEFAULT 'pending',
    run_at       TEXT NOT NULL,
    retry_count  INTEGER NOT NULL DEFAULT 0,
    max_retries  INTEGER NOT NULL DEFAULT 3,
    error        TEXT,
    started_at   TEXT,
    completed_at TEXT,
    created_at   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_forge_jobs_pending
    ON forge_jobs (job_type, run_at, status);
"""

# ---------------------------------------------------------------------------
# DML — PostgreSQL
# ---------------------------------------------------------------------------

_INSERT_JOB_POSTGRES = """
INSERT INTO forge_jobs (id, job_type, payload, run_at, max_retries, created_at)
VALUES ($1, $2, $3, $4, $5, $6)
"""

_HAS_PENDING_POSTGRES = """
SELECT COUNT(*) AS count FROM forge_jobs
WHERE job_type = $1 AND status IN ('pending', 'running')
"""

_CLAIM_NEXT_POSTGRES = """
SELECT id, job_type, payload, retry_count, max_retries
FROM forge_jobs
WHERE job_type = ANY($1)
  AND status = 'pending'
  AND run_at <= $2
ORDER BY run_at
LIMIT 1
FOR UPDATE SKIP LOCKED
"""

_MARK_RUNNING_POSTGRES = """
UPDATE forge_jobs SET status = 'running', started_at = $1 WHERE id = $2
"""

_MARK_COMPLETED_POSTGRES = """
UPDATE forge_jobs SET status = 'completed', completed_at = $1 WHERE id = $2
"""

_MARK_FAILED_POSTGRES = """
UPDATE forge_jobs SET status = 'failed', error = $1, completed_at = $2 WHERE id = $3
"""

_MARK_PENDING_POSTGRES = """
UPDATE forge_jobs SET status = 'pending', retry_count = $1 WHERE id = $2
"""

# ---------------------------------------------------------------------------
# DML — SQLite
# ---------------------------------------------------------------------------

_INSERT_JOB_SQLITE = """
INSERT INTO forge_jobs (id, job_type, payload, run_at, max_retries, created_at)
VALUES (?, ?, ?, ?, ?, ?)
"""

_HAS_PENDING_SQLITE = """
SELECT COUNT(*) FROM forge_jobs
WHERE job_type = ? AND status IN ('pending', 'running')
"""

_CLAIM_NEXT_SQLITE = """
SELECT id, job_type, payload, retry_count, max_retries
FROM forge_jobs
WHERE job_type IN ({placeholders})
  AND status = 'pending'
  AND run_at <= ?
ORDER BY run_at
LIMIT 1
"""

_MARK_RUNNING_SQLITE = """
UPDATE forge_jobs SET status = 'running', started_at = ? WHERE id = ?
"""

_MARK_COMPLETED_SQLITE = """
UPDATE forge_jobs SET status = 'completed', completed_at = ? WHERE id = ?
"""

_MARK_FAILED_SQLITE = """
UPDATE forge_jobs SET status = 'failed', error = ?, completed_at = ? WHERE id = ?
"""

_MARK_PENDING_SQLITE = """
UPDATE forge_jobs SET status = 'pending', retry_count = ? WHERE id = ?
"""
