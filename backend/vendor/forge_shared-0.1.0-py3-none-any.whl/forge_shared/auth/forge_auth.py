"""
ForgeAuth — unified auth facade for FORGE portfolio services.

Wraps JWTAuth with a simplified API designed for product-aware, tier-aware
authentication across all FORGE portfolio backends.

API:
    ForgeAuth(secret_key, algorithm, access_token_expire_minutes, refresh_token_expire_days)
    forge_auth.create_access_token(user_id, products, tier, extra)
    forge_auth.create_refresh_token(user_id)
    forge_auth.create_token_pair(user_id, products, tier)
    forge_auth.decode_token(token) -> TokenPayload
    forge_auth.require_product(token, product)
    forge_auth.require_tier(token, min_tier)
    AuthError(message, status_code)

Example:
    ```python
    from forge_shared.auth.forge_auth import ForgeAuth, AuthError

    forge_auth = ForgeAuth(
        secret_key=settings.secret_key,
        algorithm="HS256",
        access_token_expire_minutes=30,
        refresh_token_expire_days=7,
    )

    # Create tokens
    access = forge_auth.create_access_token(
        user_id="user-uuid",
        products=["interview-simulator"],
        tier="pro",
    )
    refresh = forge_auth.create_refresh_token(user_id="user-uuid")

    # Decode and validate
    payload = forge_auth.decode_token(access)
    print(payload.sub, payload.products)

    # Guard checks
    try:
        forge_auth.require_product(access, "interview-simulator")
    except AuthError as e:
        return JSONResponse(status_code=e.status_code, content={"detail": e.message})
    ```
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from forge_shared.auth.jwt import JWTAuth, JWTConfig
from forge_shared.auth.models import Permission, PlanTier, UserRole


class AuthError(Exception):
    """Raised when authentication or authorization fails.

    Attributes:
        message: Human-readable error description.
        status_code: HTTP status code appropriate for the error (401 or 403).
    """

    def __init__(self, message: str, status_code: int = 401) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code


@dataclass
class TokenPayload:
    """Decoded, validated token payload returned by ForgeAuth.decode_token().

    Attributes:
        sub: Subject — the user UUID.
        products: List of product identifiers the user has access to.
        tier: Plan tier string (e.g. "free", "pro", "enterprise").
        type: Token type — "access" or "refresh".
        exp: Expiration timestamp (Unix seconds).
        iat: Issued-at timestamp (Unix seconds).
        email: User email (may be a synthetic placeholder for refresh tokens).
        extra: Additional claims embedded in the token.
    """

    sub: str
    products: list[str]
    tier: str
    type: str
    exp: int
    iat: int
    email: str = ""
    extra: dict[str, Any] = field(default_factory=dict)


class ForgeAuth:
    """Simplified auth facade that wraps JWTAuth for FORGE product services.

    This class provides a product-aware, tier-aware JWT authentication API
    designed to be used consistently across all FORGE portfolio backends.

    Args:
        secret_key: HMAC secret key for signing tokens.
        algorithm: JWT algorithm — "HS256" (default) or "RS256".
        access_token_expire_minutes: Access token TTL in minutes (default: 30).
        refresh_token_expire_days: Refresh token TTL in days (default: 7).
        issuer: JWT issuer claim (default: "forge-core").
        audience: JWT audience claim (default: "forge-services").
    """

    def __init__(
        self,
        secret_key: str,
        algorithm: str = "HS256",
        access_token_expire_minutes: int = 30,
        refresh_token_expire_days: int = 7,
        issuer: str = "forge-core",
        audience: str = "forge-services",
    ) -> None:
        config = JWTConfig(
            secret_key=secret_key,
            algorithm=algorithm,
            access_token_expire_minutes=access_token_expire_minutes,
            refresh_token_expire_days=refresh_token_expire_days,
            issuer=issuer,
            audience=audience,
        )
        self._auth = JWTAuth(config)

    # ------------------------------------------------------------------
    # Token creation
    # ------------------------------------------------------------------

    def create_access_token(
        self,
        user_id: str,
        products: list[str] | None = None,
        tier: str = "free",
        email: str = "",
        extra: dict[str, Any] | None = None,
    ) -> str:
        """Create a signed JWT access token.

        Args:
            user_id: User UUID to embed as the ``sub`` claim.
            products: List of product identifiers the user can access.
                      Defaults to an empty list.
            tier: Plan tier string — "free", "pro", or "enterprise".
                  Defaults to "free".
            email: User email address.  When omitted a synthetic placeholder
                   ``{user_id}@forge.dev`` is used so that the token is still
                   valid against the underlying JWTAuth which requires an email.
            extra: Arbitrary extra claims to embed verbatim in the token.

        Returns:
            Signed JWT access token string.
        """
        plan = self._tier_to_plan(tier)
        effective_email = email or f"{user_id}@forge.dev"
        return self._auth.create_access_token(
            user_id=user_id,
            email=effective_email,
            domain="forge.dev",
            plan=plan,
            products=list(products or []),
            roles=[UserRole.USER],
            permissions=[Permission.READ_OWN, Permission.WRITE_OWN],
            extra_claims=extra or {},
        )

    def create_refresh_token(self, user_id: str) -> str:
        """Create a signed JWT refresh token.

        Args:
            user_id: User UUID to embed as the ``sub`` claim.

        Returns:
            Signed JWT refresh token string.
        """
        return self._auth.create_refresh_token(user_id=user_id)

    def create_token_pair(
        self,
        user_id: str,
        products: list[str] | None = None,
        tier: str = "free",
        email: str = "",
        extra: dict[str, Any] | None = None,
    ) -> tuple[str, str]:
        """Create a matched access + refresh token pair.

        Args:
            user_id: User UUID.
            products: List of product identifiers.
            tier: Plan tier string.
            email: User email address (optional).
            extra: Extra claims for the access token.

        Returns:
            Tuple of ``(access_token, refresh_token)``.
        """
        access = self.create_access_token(
            user_id=user_id,
            products=products,
            tier=tier,
            email=email,
            extra=extra,
        )
        refresh = self.create_refresh_token(user_id=user_id)
        return access, refresh

    # ------------------------------------------------------------------
    # Token validation
    # ------------------------------------------------------------------

    def decode_token(self, token: str) -> TokenPayload:
        """Decode and validate a JWT token, returning a simplified TokenPayload.

        Args:
            token: Raw JWT string.

        Returns:
            ``TokenPayload`` with decoded claims.

        Raises:
            AuthError: If the token is missing, expired, or otherwise invalid.
        """
        try:
            forge_payload = self._auth.decode_token(token)
        except Exception as exc:
            raise AuthError(f"Invalid or expired token: {exc}", status_code=401) from exc

        return TokenPayload(
            sub=forge_payload.sub,
            products=list(forge_payload.products),
            tier=forge_payload.plan.value if hasattr(forge_payload.plan, "value") else str(forge_payload.plan),
            type=forge_payload.type,
            exp=forge_payload.exp,
            iat=forge_payload.iat,
            email=str(forge_payload.email),
        )

    # ------------------------------------------------------------------
    # Guard helpers
    # ------------------------------------------------------------------

    def require_product(self, token: str, product: str) -> TokenPayload:
        """Validate the token and assert the user has access to *product*.

        Args:
            token: Raw JWT access token string.
            product: Product identifier to check (e.g. ``"interview-simulator"``).

        Returns:
            The decoded ``TokenPayload`` when the check passes.

        Raises:
            AuthError: 401 if the token is invalid; 403 if product access is missing.
        """
        payload = self.decode_token(token)
        if product not in payload.products:
            raise AuthError(
                f"Access to product '{product}' required.",
                status_code=403,
            )
        return payload

    def require_tier(self, token: str, min_tier: str) -> TokenPayload:
        """Validate the token and assert the user's tier meets *min_tier*.

        Tier ordering: free < pro < enterprise.

        Args:
            token: Raw JWT access token string.
            min_tier: Minimum required tier string.

        Returns:
            The decoded ``TokenPayload`` when the check passes.

        Raises:
            AuthError: 401 if the token is invalid; 403 if tier is insufficient.
        """
        _TIER_ORDER = {"free": 0, "pro": 1, "enterprise": 2}
        payload = self.decode_token(token)
        user_rank = _TIER_ORDER.get(payload.tier, 0)
        required_rank = _TIER_ORDER.get(min_tier, 0)
        if user_rank < required_rank:
            raise AuthError(
                f"Plan tier '{min_tier}' or higher required.",
                status_code=403,
            )
        return payload

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _tier_to_plan(tier: str) -> PlanTier:
        """Convert a tier string to a PlanTier enum value."""
        _MAP: dict[str, PlanTier] = {
            "free": PlanTier.FREE,
            "pro": PlanTier.PRO,
            "enterprise": PlanTier.ENTERPRISE,
            # Alias used by interview-simulator
            "team": PlanTier.ENTERPRISE,
        }
        return _MAP.get(tier.lower(), PlanTier.FREE)
