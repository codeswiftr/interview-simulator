"""
FastAPI dependency factories for ForgeAuth.

Provides ready-to-use dependency functions built on top of ForgeAuth,
suitable for protecting FastAPI routes with JWT authentication and
product / tier guards.

Functions:
    create_auth_dependency(auth) -> get_current_user
    create_product_guard(auth, product) -> dependency
    create_tier_guard(auth, min_tier) -> dependency

Example:
    ```python
    from fastapi import FastAPI, Depends
    from forge_shared.auth.forge_auth import ForgeAuth
    from forge_shared.auth.fastapi_deps import (
        create_auth_dependency,
        create_product_guard,
        create_tier_guard,
    )

    forge_auth = ForgeAuth(secret_key=settings.secret_key)
    get_current_user = create_auth_dependency(forge_auth)
    require_is_product = create_product_guard(forge_auth, "interview-simulator")
    require_pro = create_tier_guard(forge_auth, "pro")

    app = FastAPI()

    @app.get("/profile")
    async def profile(user=Depends(get_current_user)):
        return {"sub": user.sub, "tier": user.tier}

    @app.get("/pro-feature")
    async def pro_feature(user=Depends(require_pro)):
        return {"message": "Pro feature"}
    ```
"""

from __future__ import annotations

from typing import Callable

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from forge_shared.auth.forge_auth import AuthError, ForgeAuth, TokenPayload

_security = HTTPBearer(auto_error=False)


def create_auth_dependency(auth: ForgeAuth) -> Callable[..., TokenPayload]:
    """Return a FastAPI dependency that validates a Bearer token and returns TokenPayload.

    The returned dependency extracts the ``Authorization: Bearer <token>`` header,
    decodes it with *auth*, and returns a :class:`TokenPayload`.  If no token is
    present or the token is invalid a ``401 Unauthorized`` response is raised.

    Args:
        auth: Configured :class:`ForgeAuth` instance.

    Returns:
        An async FastAPI dependency function ``get_current_user``.

    Example:
        ```python
        forge_auth = ForgeAuth(secret_key=settings.secret_key)
        get_current_user = create_auth_dependency(forge_auth)

        @app.get("/me")
        async def me(user: TokenPayload = Depends(get_current_user)):
            return {"sub": user.sub}
        ```
    """

    async def get_current_user(
        credentials: HTTPAuthorizationCredentials | None = Depends(_security),
    ) -> TokenPayload:
        if credentials is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Not authenticated",
                headers={"WWW-Authenticate": "Bearer"},
            )
        try:
            return auth.decode_token(credentials.credentials)
        except AuthError as exc:
            raise HTTPException(
                status_code=exc.status_code,
                detail=exc.message,
                headers={"WWW-Authenticate": "Bearer"},
            ) from exc

    return get_current_user


def create_product_guard(auth: ForgeAuth, product: str) -> Callable[..., TokenPayload]:
    """Return a FastAPI dependency that requires the user to have *product* access.

    Args:
        auth: Configured :class:`ForgeAuth` instance.
        product: Product identifier to guard (e.g. ``"interview-simulator"``).

    Returns:
        An async FastAPI dependency function.

    Example:
        ```python
        require_is = create_product_guard(forge_auth, "interview-simulator")

        @app.get("/sim/start")
        async def start_sim(user: TokenPayload = Depends(require_is)):
            ...
        ```
    """
    get_current_user = create_auth_dependency(auth)

    async def product_guard(
        payload: TokenPayload = Depends(get_current_user),
    ) -> TokenPayload:
        if product not in payload.products:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access to product '{product}' required.",
            )
        return payload

    return product_guard


def create_tier_guard(auth: ForgeAuth, min_tier: str) -> Callable[..., TokenPayload]:
    """Return a FastAPI dependency that requires the user's plan tier to meet *min_tier*.

    Tier ordering: free < pro < enterprise.

    Args:
        auth: Configured :class:`ForgeAuth` instance.
        min_tier: Minimum tier string required.

    Returns:
        An async FastAPI dependency function.

    Example:
        ```python
        require_pro = create_tier_guard(forge_auth, "pro")

        @app.get("/advanced-analytics")
        async def advanced(user: TokenPayload = Depends(require_pro)):
            ...
        ```
    """
    _TIER_ORDER = {"free": 0, "pro": 1, "enterprise": 2}
    get_current_user = create_auth_dependency(auth)

    async def tier_guard(
        payload: TokenPayload = Depends(get_current_user),
    ) -> TokenPayload:
        user_rank = _TIER_ORDER.get(payload.tier, 0)
        required_rank = _TIER_ORDER.get(min_tier, 0)
        if user_rank < required_rank:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Plan tier '{min_tier}' or higher required.",
            )
        return payload

    return tier_guard
